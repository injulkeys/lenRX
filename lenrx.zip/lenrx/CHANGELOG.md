##### [Version 1.0.5](https://github.com/Codeinwp/raft/compare/v1.0.4...v1.0.5) (2022-11-22)

- Adds new Header & Footer template parts;
- Adds content block inside the front-page template;
- Adds 11 new block patterns inside the theme;
- Adds four new font families to be used with style variations;
- Fix three-column features pattern layout;

##### [Version 1.0.4](https://github.com/Codeinwp/raft/compare/v1.0.3...v1.0.4) (2022-10-24)

- Fix image block alignments

##### [Version 1.0.3](https://github.com/Codeinwp/raft/compare/v1.0.2...v1.0.3) (2022-10-07)

- change style.css description

##### [Version 1.0.2](https://github.com/Codeinwp/raft/compare/v1.0.1...v1.0.2) (2022-10-04)

- Change screenshot
- Change text in hero pattern

##### [Version 1.0.1](https://github.com/Codeinwp/raft/compare/v1.0.0...v1.0.1) (2022-09-14)

- Fix notice that was not dismissible in dashboard

####   Version 1.0.0 (2022-08-04)

- Initial release
