<?php
/**
 * Silence is golden.
 *
 * @package raft
 */
